package model;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class MovieDao {
	public void create(Movie movie)
	{
		Session session = ConnectionFactory.getConnection();
		Transaction tran = session.beginTransaction();
		session.persist(movie);
		tran.commit();
		session.close();
	}
	public void read()
	{}
	public void read(Integer id)
	{}
	public void update(Movie movie)
	{}
	public void delete(Integer id)
	{}

	public static void main(String args[])throws Exception
	{
		System.out.println("Hello world");
		MovieDao mdao=new MovieDao();
		Movie movie=new Movie();
//		movie.setId(1);					id is auto generated. so we dont supply
		movie.setName("Robo 2");
		movie.setReleaseDate(new Date());
		
		mdao.create(movie);
		System.out.println("Check db");
	}
	
}
